# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 15:54:45 2022

@author: 118939
"""

db_path = r'/Users/stevenhsu/Library/Mobile Documents/com~apple~CloudDocs/warehouse'
# 用來指定warehouse的路徑，下面可以包含很多專案，像是actual price或是stock，這個會由下面的管理器自行分類